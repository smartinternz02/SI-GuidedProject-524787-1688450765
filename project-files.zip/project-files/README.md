# Demo Video Link
https://drive.google.com/file/d/1K2eFDD8TEXpbihc9RHpISLcmYAhwQV_q/view?usp=sharing

# Dataset link
https://www.kaggle.com/datasets/thedevastator/analyzing-customer-spending-habits-to-improve-sa


# Website Link
https://swati1901.github.io/Data-Analytics/

# Link for the Dashboard
https://public.tableau.com/views/Project_DA1_Dashboard/Dashboard1?:language=en-GB&:display_count=n&:origin=viz_share_link


# Link of the Story
https://public.tableau.com/views/Project_DA_Story1/Story1?:language=en-GB&:display_count=n&:origin=viz_share_link


